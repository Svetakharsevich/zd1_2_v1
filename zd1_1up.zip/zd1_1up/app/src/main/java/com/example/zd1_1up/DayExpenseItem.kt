package com.example.zd1_1up

data class DayExpenseItem(
    val name: String,
    val expense: Double
)